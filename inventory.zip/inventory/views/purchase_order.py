from rest_framework.generics import CreateAPIView, RetrieveUpdateAPIView, DestroyAPIView, ListAPIView, UpdateAPIView
from rest_framework import status
from rest_framework.response import Response
from django.db import transaction

from inventory.models import PurchaseOrder, PurchaseOrderDetail
from inventory.serializers.purchase_order import *
from ..sql.PurchaseOrderListing import get_purchase_order
from ..models.inventory import StockOnHand

class CreatePurchaseOrder(CreateAPIView):
    serializer_class = PurchaseOrderVoucherSerializer
    
    @transaction.atomic
    def create(self, *args, **kwargs):
        serializer = self.get_serializer(data=self.request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        else:
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class PurchaseOrderListing(ListAPIView):
    serializer_class = PurchaseOrderVoucherSerializer

    def get_queryset(self):
        queryset = get_purchase_order()
        return queryset

class SubmitPurchaseOrder(UpdateAPIView):
    def get_object(self):
        queryset = self.get_queryset()

    
    def get_queryset(self, inventory_id, location_id):
        queryset = StockOnHand.objects.filter(inventory= ,location=)
    serializer_class = PurchaseOrderVoucherSerializer
    queryset = 
    lookup_field = 'purchase_order_id'

    @transaction.atomic
    def update(self, request, *args, **kwargs):
